"""
hvmCodeWriter.py -- Emits assembly language code for the Hack VM translator.
Skeletonized by Janet Davis March 2016
Refactored by John Stratton April 2017
Refactored by Janet Davis March 2019
Updated by Cary Gray March 2021
"""

import os
from hvmCommands import *

# If debug is True, 
# then the VM commands will be written as comments into the output ASM file.
debug = True

table = { T_ARGUMENT: "ARG", # Defined this table as a global variable as a bug workaround
        T_LOCAL: "LCL",
        T_THIS: "THIS",
        T_THAT: "THAT" }


class CodeWriter(object):
    
    def __init__(self, outputName):
        """
        Opens 'outputName' and gets ready to write it.
        """
        self.file = open(outputName, 'w')
        self.fileName = self.setFileName(outputName)

        # used to generate unique labels
        self.labellabelber = 0
        self.functionName = ""
        self.call_count = 0


    def close(self):
        """
        Writes the terminal loop and closes the output file.
        """
        label = self._uniqueLabel()
        self._writeComment("Infinite loop")
        self._writeCode('({0}), @{0}, 0;JMP'.format(label))
        self.file.close()


    def setFileName(self, fileName):
        """
        Sets the current file name to 'fileName'.
        Restarts the local label counter.

        Strips the path and extension.  The resulting name must be a
        legal Hack Assembler identifier.
        """
        self.fileName = os.path.basename(fileName)
        self.fileName = os.path.splitext(self.fileName)[0]

    def _uniqueLabel(self):
        self.labellabelber += 1;
        return "label" + str(self.labellabelber)

    def write(self, text):
        """ 
        Write directly to the file.
        """
        self.file.write(text)

    def _writeCode(self, code):
        """
        Writes Hack assembly code to the output file.
        code should be a string containing ASM commands separated by commas,
        e.g., "@10, D=D+A, @0, M=D"
        """
        code = code.replace(',', '\n').replace(' ', '')
        self.file.write(code + '\n')

    def _writeComment(self, comment):
        """
        Writes a comment to the output ASM file.
        """
        if (debug):
            self.file.write('    // {0}\n'.format(comment))

    def _pushD(self):
        """
        Writes Hack assembly code to push the value from the D register 
        onto the stack.
        TODO - Stage I - see Figure 7.2
        """
        # self._writeComment("Store D at stack[sp], sp++")
        code = "@SP, A=M, M=D, @SP, M=M+1"
        self._writeCode(code)

    def _popD(self):
        """"
        Writes Hack assembly code to pop a value from the stack 
        into the D register.
        TODO - Stage I - see Figure 7.2
        """
        # self._writeComment("sp--, store stack[sp] in D")
        code = "@SP, AM=M-1, D=M"
        self._writeCode(code)

    def writeArithmetic(self, command):
        """
        Writes Hack assembly code for the given command.
        TODO - Stage I - see Figure 7.5
        """
        self._writeComment(command);

        if command == T_ADD:
            self._popD() # Pop x
            self._writeCode("@R15, M=D") # Store value x in R15
            self._popD() # Pop y
            self._writeCode("@R15, D=D+M")  # Back to R15,  
            self._pushD() # Push result

        elif command == T_SUB: # Same idea as T_ADD
            self._popD()
            self._writeCode("@R15, M=D")
            self._popD()
            self._writeCode("@R15, D=D-M")
            self._pushD()

        elif command == T_NEG:
            self._popD()
            self._writeCode("D=-D")
            self._pushD()

        elif command == T_EQ:   # Because of how long these are, I just manually wrote the assembly instead of wedging pushD/popD in
            self._writeCode("""    
                            @SP
                            AM=M-1
                            D=M     
                            A=A-1
                            D=M-D
                            @EQ_{label}
                            D;JEQ
                            @SP
                            A=M-1
                            M=0
                            @END_{label}
                            0;JMP
                            (EQ_{label})
                            @SP
                            A=M-1
                            M=-1
                            (END_{label})
                            """.format(label=self._uniqueLabel()))
        
        elif command == T_GT:
            self._writeCode("""
                            @SP
                            AM=M-1
                            D=M
                            A=A-1
                            D=M-D
                            @GT_{label}
                            D;JGT
                            @SP
                            A=M-1
                            M=0
                            @END_{label}
                            0;JMP
                            (GT_{label})
                            @SP
                            A=M-1
                            M=-1
                            (END_{label})
                            """.format(label=self._uniqueLabel()))

        elif command == T_LT:
            self._writeCode("""
                            @SP
                            AM=M-1
                            D=M
                            A=A-1
                            D=M-D
                            @LT_{label}
                            D;JLT
                            @SP
                            A=M-1
                            M=0
                            @END_{label}
                            0;JMP
                            (LT_{label})
                            @SP
                            A=M-1
                            M=-1
                            (END_{label})""".format(label=self._uniqueLabel()))

        elif command == T_AND:
            self._popD()
            self._writeCode("@R15, M=D")
            self._popD()
            self._writeCode("@R15, D=D&M")
            self._pushD()

        elif command == T_OR:
            self._popD()
            self._writeCode("@R15, M=D")
            self._popD()
            self._writeCode("@R15, D=D|M")
            self._pushD()

        elif command == T_NOT:
            self._popD()
            self._writeCode("D=!D")
            self._pushD()

        else:
            raise(ValueError, 'Bad arithmetic command')
    

    def _translateSegment(self, segment): 
        """
        For whatever reason, this wouldn't work for me. It was returning the value of T_xxx as specified in hvmCommands
        So I just worked around it by making the dict into a global variable
        """
        return { T_ARGUMENT: "ARG",
                 T_LOCAL: "LCL",
                 T_THIS: "THIS",
                 T_THAT: "THAT" }[segment]

        
    def writePushPop(self, commandType, segment, index):
        """
        Write Hack code for 'commandType' (C_PUSH or C_POP).
        'segment' (string) is the segment name.
        'index' (int) is the offset in the segment.
        e.g., for the VM instruction "push constant 5",
        segment has the value "constant" and index has the value 5.
        TODO - Stage I - push constant only
        TODO - Stage II - See Figure 7.6 and pp. 142-3
        """

        if commandType == C_PUSH:
            self._writeComment("push {0} {1:d}".format(segment, index))

            if segment == T_CONSTANT:
                self._writeCode("@{}\n".format(index))
                self._writeCode("D=A")
                self._pushD() 

            elif segment == T_STATIC:
                self._writeCode("@{0}.{1}, D=M".format(self.fileName, index))
                self._pushD()

            elif segment == T_POINTER:
                self._writeCode("@R3, D=A")
                self._writeCode("@{}, D=D+A, A=D, D=M".format(index))
                self._pushD()

            elif segment == T_TEMP:
                self._writeCode("@R5, D=A")
                self._writeCode("@{}, D=D+A, A=D, D=M".format(index))
                self._pushD()

            else: # argument, local, this, that
                self._writeCode("@{}, D=M".format(table[segment]))
                self._writeComment("Store base address of {0} in D and then increment D by {1}".format(segment, index))
                self._writeCode("@{}, D=D+A, A=D, D=M".format(index))
                self._pushD()

        elif commandType == C_POP:
            self._writeComment("pop {0} {1:d}".format(segment, index))
            current_label = self._uniqueLabel() # Declaring this here ensures we don't increment the label index unnecessarily 

            if segment == T_STATIC:
                self._popD()
                self._writeCode("@{0}.{1}, M=D".format(self.fileName, index))

            elif segment == T_POINTER: # All the pop methods below use the same idea of storing the adjusted memory address in a free register
                self._writeCode("@R3, D=A")
                self._writeCode("@{}, D=D+A".format(index))

                self._writeComment("Save adjusted address for later")

                self._writeCode("@addr_{}, M=D".format(current_label))
                self._popD()
                self._writeCode("@addr_{}, A=M, M=D".format(current_label))

            elif segment == T_TEMP:
                self._writeCode("@R5, D=A")
                self._writeCode("@{}, D=D+A".format(index))

                self._writeComment("Save adjusted address for later")

                self._writeCode("@addr_{}, M=D".format(current_label))
                self._popD()
                self._writeCode("@addr_{}, A=M, M=D".format(current_label))

            else: # argument, local, this, that
                self._writeCode("@{}, D=M".format(table[segment]))
                self._writeCode("@{}, D=D+A".format(index))

                self._writeComment("Save adjusted address for later")

                self._writeCode("@addr_{}, M=D".format(current_label))
                self._popD()
                self._writeCode("@addr_{}, A=M, M=D".format(current_label))

        else:
            raise(ValueError, 'Bad push/pop command')


# Functions below this comment are for Project 08. Ignore for Project 07.

    def writeLabel(self, label):
        """ 
        Writes assembly code that effects the label command.
        See section 8.2.1 and Figure 8.6.
        """
        label = (self.fileName + "$" + label)
        self._writeComment("label %s" % (label))
        self._writeCode("(" + label + ")")

    def writeGoto(self, label):
        """
        Writes assembly code that effects the goto command.
        See section 8.2.1 and Figure 8.6.
        """
        label = (self.fileName + "$" + label)
        self._writeComment("goto %s" % (label))
        self._writeCode("@" + label + ", 0;JMP")

    def writeIf(self,label):
        """
        Writes assembly code that effects the if-goto command.
        See section 8.2.1 and Figure 8.6.
        """
        label = (self.fileName + "$" + label)
        self._writeComment("if-goto %s" % (label))
        self._popD()
        self._writeCode("@"+ label +", D;JNE")

    def writeFunction(self, functionName, labelLocals):
        """
        Writes assembly code that effects the function command.
        See Figures 8.5 and 8.6.
        """
        self._writeCode("(" + functionName + ")")
        self._writeComment("function {0} {1:d}".format(functionName, labelLocals))
        #self.functionName = functionName # For local labels
        for i in range(labelLocals):
            self._writeCode("D=0")
            self._pushD()
        

    def writeReturn(self):
        """
        Writes assembly code that effects the return command.
        See Figure 8.5.
        """

        # FRAME = LCL
        self._writeCode('@LCL, D=M')
        self._writeCode('@R13, M=D')

        # RET = *(FRAME-5)
        self._writeCode('@R13, D=M')
        self._writeCode('@5')
        self._writeCode('D=D-A')
        self._writeCode('A=D') 
        self._writeCode('D=M') 
        self._writeCode('@R14, M=D')

        # *ARG = pop()
        self._popD()
        self._writeCode('@ARG')
        self._writeCode('A=M')
        self._writeCode('M=D')

        # SP = ARG+1
        self._writeCode('@ARG, D=M')
        self._writeCode('@SP, M=D+1')

        # THAT = *(FRAME-1)
        # THIS = *(FRAME-2)
        # ARG = *(FRAME-3)
        # LCL = *(FRAME-4)
        i = 1
        for address in ['@THAT', '@THIS', '@ARG', '@LCL']:
            self._writeCode('@R13, D=M')
            self._writeCode('@' + str(i))
            self._writeCode('D=D-A') 
            self._writeCode('A=D') 
            self._writeCode('D=M') 
            self._writeCode(address)
            self._writeCode('M=D') 
            i += 1

        # goto RET
        self._writeCode('@R14, A=M')
        self._writeCode('0;JMP')
        

    def writeCall(self, functionName, labelArgs):
        """
        Writes assembly code that effects the call command.
        See Figures 8.5 and 8.6.
        """

        RET = self._uniqueLabel()

        # push return-address
        self._writeCode('@' + RET + ', D=A')
        self._pushD()

        # push LCL
        # push ARG
        # push THIS
        # push THAT
        for address in ['@LCL', '@ARG', '@THIS', '@THAT']:
            self._writeCode(address + ',D=M')
            self._pushD()

        # LCL  = SP
        self._writeCode('@SP, D=M')
        self._writeCode('@LCL, M=D')

        # ARG = SP-n-5
        self._writeCode('@' + str(labelArgs + 5) + ',D=D-A')
        self._writeCode('@ARG, M=D')

        # goto f
        self._writeCode('@' + functionName)
        self._writeCode('0;JMP')

        # (return address)
        self._writeCode("(" + RET + ")")


    def writeInit(self):
        """
        Writes assembly code that effects the VM initialization,
        also called bootstrap code. This code must be placed
        at the beginning of the output file.
        See p. 165, "Bootstrap Code"
        """
        self._writeCode('@256, D=A')
        self._writeCode('@SP, M=D')
        self.writeCall('Sys.init', 0)



















