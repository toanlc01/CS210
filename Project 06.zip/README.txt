~~~ Project 07 ~~~
Written by Gabe Kelly & Cong Toan Le

Code was done collaboratively. Our approach was to write pseudo-assembly code for each VM command beforehand and then implementing it. Everything is
working well and it is passing all of the tests. The only thing worth noting as far as bugs was the issues we had with _translateSegment(). For some reason
it just wouldn't work, for example, _translateSegment(T_ARGUMENT) returned the string "argument" instead of "ARG". Several workarounds were tried but in the end what
worked was ignoring the function entirely and just making the dictionary into a global variable. We broke from the convention of using _writeCode for the 
implementations of EQ, GT, and LT because there was enough code to write for each that the multi-line string was just more readable.