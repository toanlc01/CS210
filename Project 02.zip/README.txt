Who contributes to the project:
- Julian Le
- Riley Gronlund
All parts work as it passes all tests on HardwareSimulator.
