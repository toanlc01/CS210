Project 1 Members: Julian Le and Joshua Shin

All parts of the project are working. There are no parts that are incomplete. Everything ran to completion on the hardware simulator.

We both worked on this project equally.
